package dp.dataconverter.mp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

public class DataConverter {

	public static void main(String[] args) throws ParseException {

		Options options = new Options();
		Option data = Option.builder().longOpt("data").argName("DataReciever").hasArg().desc("Use Option to submit data").build();
		options.addOption(data);
		CommandLineParser parser = new DefaultParser();
		CommandLine cmd = parser.parse(options, args);

		// has the logFile argument been passed?
		if (cmd.hasOption("data")) {
			// get the logFile argument passed
			System.out.println(cmd.getOptionValue("data"));
		}

		/*URL url = null;

		try {
			url = new URL("https://61a8cda033e9df0017ea3b0c.mockapi.io/api/v1/nodes");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		HttpURLConnection con = null;
		try {
			con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "application/json; utf-8");
			con.setRequestProperty("Accept", "application/json");
			con.setDoOutput(true);
			String jsonInputString = "{\"name\": \"Upendra\", \"job\": \"Programmer\"}";
			try (OutputStream os = con.getOutputStream()) {
				byte[] input = jsonInputString.getBytes("utf-8");
				os.write(input, 0, input.length);
			}
			try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"))) {
				StringBuilder response = new StringBuilder();
				String responseLine = null;
				while ((responseLine = br.readLine()) != null) {
					response.append(responseLine.trim());
				}
				System.out.println(response.toString());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}*/
	}
}
